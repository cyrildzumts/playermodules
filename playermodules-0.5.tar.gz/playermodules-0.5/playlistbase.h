#ifndef PLAYLISTBASE_H
#define PLAYLISTBASE_H
#include <QtCore>
#include "utils.h"

class PlaylistBase
{

public:
  PlaylistBase();
  virtual ~PlaylistBase();

  // core members. These doesn't need to be reimplemented
  virtual void next() ;
  virtual void previous();
  virtual bool isActive();
  virtual void setIsActive(bool active);
  virtual QString title()const;
  virtual void setTitle(QString trackTitle);
  virtual QString artist()const;
  virtual void setArtist(QString trackArtist);
  virtual QString albumTitle() const;
  virtual void setAlbumTitle(QString album);
  virtual QString playlistTitle()const;
  virtual void setPlaylistTitle(QString plsTitle);
  virtual int length()const;
  virtual void setLength(int l);
  virtual int duration()const;
  virtual void setDuration(int d);
  virtual int bitrate()const;
  virtual void setBitrate(int rate);
  virtual int trackCount()const;
  virtual void setTrackCount(int count);
  virtual QString cover()const;
  virtual void setCover(QString path);
  virtual QString trackUrl()const;
  virtual void setTrackUrl(QString url);
  virtual Utils::PlaybackMode playbackMode()const;
  virtual void setPlaybackMode(Utils::PlaybackMode mode);
  virtual int currentIndex()const;
  virtual void setCurrentIndex(int index);
  virtual QString format()const;
  virtual void setFormat(QString f);
  virtual int nextIndex(int steps = 1) const;
  virtual int previousIndex(int steps = 1) const;

  // special Members : these member's definitions depend on the model the data will be taken from.
  // they have to be pure virtual functions.
  virtual void clear() = 0;
  virtual void addMedia(QString path) = 0;
  virtual void addMedia(int albumID) = 0;
  virtual  QString media(int pos = -1) = 0;
  virtual void removeMedia(int pos)= 0;
  virtual void deplace(int currentPos, int endPos)=0;
  virtual void insertMedia()=0;
  virtual bool canGoNext()= 0;
  virtual void save(QString plsFormat) = 0;



public:

protected:
  QString _format;
  QString _title;
  QString _artist;
  QString _albumTitle;
  QString _genre;
  QString _playlistTitle;
  QString _cover;
  QString _trackUrl;
  int _trackCount;
  int _bitrate;
  int _currentIndex;
  int _year;
  int _length;
  int _duration;
  Utils::PlaybackMode _playbackMode;
  bool  _isActive;
};

#endif // PLAYLISTBASE_H
