#ifndef DATAB_H
#define DATAB_H

#include <QQuickItem>
#include <QtSql>
#include <QDirIterator>
#include <iostream>
#include <QDateTime>
#include "m3utools.h"
#include "updatedb.h"
#include "Types.h"


class  DataB: public QQuickItem
{
    Q_OBJECT

    //Q_PROPERTY(QString createPlaylist WRITE createPlaylist   NOTIFY playlistsModelChanged)
public:
    DataB(QQuickItem *parent = 0);
   // ~DataB();

public Q_SLOTS:

    void playcountUP(int trackID);
    void updateAlbumPlayDate(int albumID);
    void updateDATABASE();
    QStringList dirList()const;
    void showDirsList()const;
    // as for Qt the created Date is the same as the lastModified Date
    // new Dirs and changed Dirs are stored in modifiedDirs.
    void setChangedDirs(QList<int> &deletedDirs, QStringList &modifiedDirs );

    QList<int> deletedFolder();
    QStringList changedDirs(QList<int> *deletedDirs);
    //void scannDatabase();
    bool addToPlaylist(int playlistID, int trackID);
    bool removeFromPlaylist(int playlistID, int trackID);
    int createPlaylist(QString name); //  return the playlistID
    bool removePlaylist(int playlistID);
    void fillDATABASE(const QString &dirPath, QSqlQuery *musicQuery);
    void addCover(const QString &path, QString &cover); //DONE
    void databaseLiveUpdate(); // for now it the 98% the same as updateDATABASE(). See the implementations for more details
    bool isFullUpdateChecked(){ return fullUpdate;}
    void setFullUpdate(bool state) { fullUpdate = state;}

    /*
     *
     *checkEntryPresence() return an Object depending on the the result of the
     *of the check.  It might be an Int ( ID, Primary Key), oder a String
     */
    //int checkEntryPresence(QString tableName, QString colName, QString str);

    void setSourceDir(QString &path);
    QString getDatabaseName() const;
    QString getDatabaseDir()const;
    void setDatabaseName(QString DBname);
    void setDatabaseDir(QString dir);

Q_SIGNALS:
    void updateJobFinished();
    void playlistsModelChanged();
    void databaseChanged();
    void directoryDeleted(QList<int> dirs);
private:
    void updateAlbum(int albumID, QString &dirpath);
    void updateAlbums(QStringList &paths);
    void dropAlbum(QList<int> &dirs);
    void addAlbums(QStringList &paths);
    bool copy(QString newName)const;
    bool copy(QString oldName, QString newName) const;
    bool remove(QString fileName)const;
    bool rename(QString oldName, QString newName) const;
    bool rename(QString newName) const;
private:


    bool fullUpdate;
    bool startupUdate;
    uint lastmodified;
    QString sourceDir;
    QString databaseDir;
    QString databaseName;
    QString newName;
    QString fileName;
    QString connectionName;
    //QSqlDatabase musicDB;


};


#endif // DATAB_H
