#include "m3utools.h"




TrackTag M3UTools::tagreaderTAGLIB(QString file)
{
    TagLib::FileRef f(file.toStdString().c_str());
    TagLib::Tag *mytag  = f.file()->tag();
    TrackTag track;

    // DEBUG ID3V2

    {
        qDebug() << "####### DEBUG ID3V2 START ######";
        qDebug() << mytag->album().toCString();
        qDebug() << mytag->artist().toCString();
        qDebug() << mytag->title().toCString();
        qDebug() << mytag->track();
        qDebug() << mytag->year();
        qDebug() << "####### DEBUG ID3V2 END ######";

    }
    if(!f.isNull() && f.tag())
    {
      TagLib::Tag  *tag = f.tag();
      track.title = QString( tag->title().toCString(true));
      track.path = file;
      track.artist = QString(tag->artist().toCString(true)) ;
      track.position = tag->track();
      track.albumTitle = tag->album().toCString(true);
      track.genre = tag->genre().toCString(true);
      track.year = tag->year();
      if(!f.audioProperties())
      {

        TagLib::AudioProperties *properties = f.audioProperties();
        track.length = properties->length() ;
      }
    }

    return track;
}

TrackTag M3UTools::tagreaderID3LIB(QString file)
{
   ID3_Tag tag ;
   TrackTag track;
   ID3_Frame *frame ;

   tag.Link((file.toStdString().c_str()));



       track.path = file;
       track.albumTitle = QString (ID3_GetAlbum(&tag));
       track.artist = QString( ID3_GetArtist(&tag));
       track.title = QString (ID3_GetTitle(&tag));
       track.genre = QString(ID3_GetGenre(&tag));
       // Length Frame
       frame = tag.Find(ID3FID_SONGLEN);
       if (NULL != frame)
         {
           char buffer[10];
           track.length = frame->GetField(ID3FN_TEXT)->Get(buffer,30);
         }
       track.position = ID3_GetTrackNum(&tag);
       track.year = QString(ID3_GetYear(&tag)).toInt();


    // DEBUG ID3V2

    {
        qDebug() << "####### DEBUG ID3V2 START ######";
        qDebug() << track.albumTitle;
        qDebug() << track.artist;
        qDebug() << track.title;
        qDebug() << track.position;
        qDebug() << track.year;
        qDebug() << "####### DEBUG ID3V2 END ######";

    }
    return track;
}

QStringList M3UTools::readM3U(QString pls)
{
    QStringList tmpList;
    QFile playlist(pls);
    playlist.open(QIODevice::ReadOnly);
    QString line;

    QTextStream readPls(&playlist);


    while (!readPls.atEnd())
    {
        line = readPls.readLine();
        if (line.startsWith("#") || line.isEmpty())
            ;
        else
        {
            //populate the playlist : read the the file,
            // retreive the paths contained in the file
            // first check it is a relative path
            if(QFileInfo::exists(line))
                // The file exists, store the file path.
                tmpList.push_back(line);
            else
            {
                // we have then a relative path. we have to transform it
                // to an absolute path.

                QFileInfo file(pls);
                QString path = file.path() + "/" + line;
                if(QFileInfo::exists(path))
                    tmpList.push_back(file.path() + "/" + line);
            }
        }

    }

    return QStringList(tmpList);

}


bool M3UTools::writeM3U(QString playlistName, QString audioFile)
{
    QString playlistDir = QDir::homePath() + "/MyPlayer/Playlist";
    QString path = playlistDir +"/" + playlistName + ".m3u";
    M3UTools::createM3UFile(playlistName);
    if (QFile::exists(path))
    {
        QString trackInfos ;
        QFile playlist(path);
        playlist.open(QIODevice::ReadWrite|QIODevice::Append);
        QTextStream writePls(&playlist);
        TrackTag track = tagreader(audioFile);
        QString separator = "\n";
        trackInfos = QString("#EXTINF:%1, %2 - %3\n").arg(QString::number(track.length),track.artist,track.title);
        writePls << separator;
        writePls << trackInfos;
        writePls << track.path;
        return true;
    }
    return false;
}


bool M3UTools::writeM3U(QString playlistName, QStringList audioFiles)
{

    QString playlistDir = QDir::homePath() + "/MyPlayer/Playlist";
    QString path = playlistDir +"/" + playlistName + ".m3u";
    M3UTools::createM3UFile(playlistName);
    if (QFile::exists(path))
    {
        QFile playlist(path);
        playlist.open(QIODevice::ReadWrite|QIODevice::Append);
        QTextStream writePls(&playlist);
        TrackTag track ;
        QString trackInfos;
        QString separator = "\n";
        for (int i = 0; i < audioFiles.count() ; ++i)
        {
            track = tagreader(audioFiles.at(i));
            trackInfos = QString("#EXTINF:%1, %2 - %3\n").arg(QString::number(track.length),track.artist,track.title);
            writePls << separator;
            writePls << trackInfos;
            writePls << track.path;
        }

        return true;
    }
    return false;
}

bool M3UTools::createM3UFile(QString filename)
{
    // simple create a playlist file with the given name

    QString playlistDir = QDir::homePath() + "/MyPlayer/Playlist";
    QString path = playlistDir +"/" + filename + ".m3u";

    if (!QFile::exists(path))
    {
        QFile playlist(path);
        QString header = "#EXTM3U";
        playlist.open(QIODevice::ReadWrite);
        QTextStream writePls(&playlist);
        writePls << header;
        return true;
    }
    return false;
}

QString M3UTools::M3UPlaylistName(QString file)
{
    //DEBUG
    qDebug()<< "#######DEBUG M3UTools::M3UPlaylistName(name)"  ;
      if(!QFileInfo::exists(file))
      {
        qDebug()<< "ERROR : the File : " << file << " doesn't exist";
        exit(1);
      }
      else
      {
          qDebug()<< "SUCCES : the File : " << file << " exists";
          QFileInfo pls(file);
          return pls.baseName();
      }


}

void M3UTools::tagreader(TagList *sameTag, TagList *diffTag, QDir parent)
{

}


TrackTag M3UTools::tagreader(QString file)
{
    QFileInfo audiofile(file);
    QString ext = audiofile.suffix().toLower();

    if (ext == "mp3")
         return tagreaderMPEG(file);
    if (ext == "flac")
         return tagreaderFLAC(file);
    if (ext == "wma")
         return tagreaderWMA(file);
    if (ext == "ogg")
         return tagreaderOGG(file);
    if ((ext == "m4a" )|| (ext == "mp4"))
         return tagreaderMP4(file);
    else
    {
         TrackTag error;
         qDebug()<< "ERROR: File type ."+ ext + " is not supported" ;
         return error;
    }
}

// MP3 TAGS READER
TrackTag M3UTools::tagreaderMPEG(QString file)
{
    TagLib::MPEG::File audioFile (file.toStdString().c_str());
    TrackTag track;

    TagLib::MPEG::Properties *audioproperties = audioFile.audioProperties();

    if (audioFile.hasID3v2Tag())
    {
        qDebug ()  << "No valide ID3V1 Tag for that file : " +  file ;
        TagLib::ID3v2::Tag *tag = audioFile.ID3v2Tag();
        track.albumTitle = tag->album().toCString();
        track.artist = tag->artist().toCString();
        track.genre = tag->genre().toCString();
        track.path = file;
        track.title = tag->title().toCString();
        track.year = tag->year();
        track.position = tag->track();
        track.length = audioproperties->length();
        track.bitRate = audioproperties->bitrate();
        tag = NULL;
        audioproperties = NULL;

    }

    else if(audioFile.hasID3v1Tag())
    {
        qDebug ()  << "No valide ID3V2 Tag for that file : " +  file ;
        TagLib::ID3v1::Tag *tag = audioFile.ID3v1Tag();
        track.albumTitle = QString(tag->album().toCString());
        track.artist = QString(tag->artist().toCString());
        track.genre = QString (tag->genre().toCString());
        track.path = file;
        track.title = QString(tag->title().toCString());
        track.year = tag->year();
        track.position = tag->track();
        track.length = audioproperties->length();
        track.bitRate = audioproperties->bitrate();
        tag = NULL;
        audioproperties = NULL;

    }
    return track;
}


// FLAC TAGS READER
TrackTag M3UTools::tagreaderFLAC(QString file)
{
    TagLib::FLAC::File audioFile (file.toStdString().c_str());
    TrackTag track;

    TagLib::FLAC::Properties *audioproperties = audioFile.audioProperties();

    if (audioFile.hasID3v1Tag())
    {
        TagLib::ID3v1::Tag *tag = audioFile.ID3v1Tag();
        track.albumTitle = QString(tag->album().toCString(true));
        track.artist = QString(tag->artist().toCString(true));
        track.genre = QString (tag->genre().toCString(true));
        track.path = file;
        track.title = QString(tag->title().toCString(true));
        track.year = tag->year();
        track.position = tag->track();
        if(audioproperties)
        {
            track.length = audioproperties->length();
            track.bitRate = audioproperties->bitrate();
        }
        tag = NULL;
        audioproperties = NULL;
    }

    else if(audioFile.hasID3v2Tag())
    {
        qDebug ()  << "No valide ID3V2 Tag for that file : " +  file ;
        TagLib::ID3v2::Tag *tag = audioFile.ID3v2Tag();
        track.albumTitle = QString(tag->album().toCString(true));
        track.artist = QString(tag->artist().toCString(true));
        track.genre = QString (tag->genre().toCString(true));
        track.path = file;
        track.title = QString(tag->title().toCString(true));
        track.year = tag->year();
        track.position = tag->track();
        if(audioproperties)
        {
            track.length = audioproperties->length();
            track.bitRate = audioproperties->bitrate();
        }
        tag = NULL;
        audioproperties = NULL;
    }
    else
    {
        TagLib::Ogg::XiphComment *tag  = audioFile.xiphComment();
        track.albumTitle = QString(tag->album().toCString(true));
        track.artist = QString(tag->artist().toCString(true));
        track.genre = QString (tag->genre().toCString(true));
        track.path = file;
        track.title = QString(tag->title().toCString(true));
        track.year = tag->year();
        track.position = tag->track();
        if(audioproperties)
        {
            track.length = audioproperties->length();
            track.bitRate = audioproperties->bitrate();
        }
        tag = NULL;
        audioproperties = NULL;
    }
    return track;
}



// OGG TAGS READER
TrackTag M3UTools::tagreaderOGG(QString file)
{
    TagLib::Ogg::Vorbis::File audioFile (file.toStdString().c_str());
    TrackTag track;
    TagLib::Ogg::XiphComment *tag = audioFile.tag();
    TagLib::Ogg::Vorbis::AudioProperties *audioproperties = audioFile.audioProperties();

    if (tag)
    {
        track.albumTitle = QString(tag->album().toCString());
        track.artist = QString(tag->artist().toCString());
        track.genre = QString (tag->genre().toCString());
        track.path = file;
        track.title = QString(tag->title().toCString());
        track.year = tag->year();
        track.position = tag->track();
        if(audioproperties)
        {
            track.length = audioproperties->length();
            track.bitRate = audioproperties->bitrate();
        }
        tag = NULL;
        audioproperties = NULL;
    }


    return track;
}


// MP4 TAGS READER
TrackTag M3UTools::tagreaderMP4(QString file)
{
    TagLib::MP4::File audioFile (file.toStdString().c_str());
    TrackTag track;
    TagLib::MP4::Tag * tag = audioFile.tag();
    TagLib::MP4::Properties *audioproperties = audioFile.audioProperties();

    if (tag)
    {
        track.albumTitle = QString(tag->album().toCString());
        track.artist = QString(tag->artist().toCString());
        track.genre = QString (tag->genre().toCString());
        track.path = file;
        track.title = QString(tag->title().toCString());
        track.year = tag->year();
        track.position = tag->track();
        if(audioproperties)
        {
            track.length = audioproperties->length();
            track.bitRate = audioproperties->bitrate();
        }
        tag = NULL;
        audioproperties = NULL;
    }

    return track;
}


// WMA TAGS READER
TrackTag M3UTools::tagreaderWMA(QString file)
{
    TagLib::ASF::File audioFile (file.toStdString().c_str());
    TrackTag track;
    TagLib::ASF::Tag *tag = audioFile.tag();
    TagLib::ASF::Properties *audioproperties = audioFile.audioProperties();

    if (tag)
    {

        track.albumTitle = QString(tag->album().toCString());
        track.artist = QString(tag->artist().toCString());
        track.genre = QString (tag->genre().toCString());
        track.path = file;
        track.title = QString(tag->title().toCString());
        track.year = tag->year();
        track.position = tag->track();
        if(audioproperties)
        {
            track.length = audioproperties->length();
            track.bitRate = audioproperties->bitrate();
        }
        tag = NULL;
        audioproperties = NULL;
    }


    return track;
}

QString M3UTools::cover(QString audioFile)
{
    QFileInfo file(audioFile);
    QString path = file.path();
    QDirIterator workingDir (path, QStringList()<< "*.jpeg "<< "*.jpg" << "*.png" << "*.svg",QDir::Files | QDir::NoDotAndDotDot,QDirIterator::Subdirectories);

    if (workingDir.hasNext())
    {

              return QString(workingDir.next());

    }
    else
        return QString("");
}
