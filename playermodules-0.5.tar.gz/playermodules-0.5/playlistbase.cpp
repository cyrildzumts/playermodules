#include "playlistbase.h"

PlaylistBase::PlaylistBase()
{
  _title = QString();
  _artist = QString();
  _albumTitle = QString();
  _genre = QString();
  _playlistTitle = QString();
  _cover = QString();
  _trackUrl = QString();
  _trackCount = 0;
  _bitrate = 0;
  _currentIndex = -1;
  _year = 0;
  _length = 0;
  _duration = 0;
  _playbackMode = Utils::PlaybackMode::Sequential;
  _isActive = false;
}

PlaylistBase::~PlaylistBase()
{

}

void PlaylistBase::next()
{
  if(canGoNext())
    {
      _currentIndex++;
    }
}


void PlaylistBase::previous()
{
  _currentIndex--;
}

bool PlaylistBase::isActive()
{
  return _isActive;
}

void PlaylistBase::setIsActive(bool active)
{
  _isActive = active;
}

QString PlaylistBase::title()const
{
  return _title;
}

void PlaylistBase::setTitle(QString trackTitle)
{
  _title = trackTitle;
}


QString PlaylistBase::artist()const
{
  return _artist;
}

void PlaylistBase::setArtist(QString trackArtist)
{
  _artist = trackArtist;
}

QString PlaylistBase::albumTitle()const
{
  return _albumTitle;
}

void PlaylistBase::setAlbumTitle(QString album)
{
  _albumTitle = album;
}

QString PlaylistBase::playlistTitle()const
{
  return _playlistTitle;
}

void PlaylistBase::setPlaylistTitle(QString plsTitle)
{
  _playlistTitle = plsTitle;
}

int PlaylistBase::length()const
{
  return _length;
}
void PlaylistBase::setLength(int l)
{
  _length = l;
}

int PlaylistBase::duration()const
{
  return _duration;
}

void PlaylistBase::setDuration(int d)
{
  _duration = d;
}

int PlaylistBase::bitrate()const
{
  return _bitrate;
}

void PlaylistBase::setBitrate(int rate)
{
  _bitrate = rate;
}

int PlaylistBase::trackCount()const
{
  return _trackCount;
}

void PlaylistBase::setTrackCount(int count)
{
  _trackCount = count;
}


QString PlaylistBase::cover()const
{
  return _cover;
}

void PlaylistBase::setCover(QString path)
{
  _cover = path;
}

QString PlaylistBase::trackUrl()const
{
  return _trackUrl;
}

void PlaylistBase::setTrackUrl(QString url)
{
  _trackUrl = url;
}

Utils::PlaybackMode PlaylistBase::playbackMode()const
{
  return _playbackMode;
}

void PlaylistBase::setPlaybackMode(Utils::PlaybackMode mode)
{
  _playbackMode = mode;
}

int PlaylistBase::currentIndex()const
{
  return _currentIndex;
}

void PlaylistBase::setCurrentIndex(int index)
{
  _currentIndex = index;
}

QString PlaylistBase::format()const
{
  return _format;
}

void PlaylistBase::setFormat(QString f)
{
  _format = f;
}

int PlaylistBase::nextIndex(int steps) const
{
  return _currentIndex + steps;
}

int PlaylistBase::previousIndex(int steps) const
{
  return _currentIndex - steps;
}
