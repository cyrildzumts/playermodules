#include "fileprepare.h"
#include <iostream>

//FilePrepare::FilePrepare()
//{

//}

void FilePrepare::clear()
{

    dirList.clear();
    tracksReady.clear();
    albums.clear();
}

void FilePrepare::run()
{
    //producer = std::thread(&FilePrepare::produceFiles, this);
    updater = std::thread(&FilePrepare::produceFilesAndReadTag, this);
    //display = std::thread(&FilePrepare::showDirList, this);
    //producer.join();
    updater.join();
    //display.join();
}

void FilePrepare::produceNewFiles()
{

    if(QFile::exists(path))
    {
        std::vector<QString> urls,urlsFromDatabase;
        urlsFromDatabase = database.getTrackUrls();
        QDir::Filters filter = QDir::Dirs|QDir::Files | QDir::NoDotAndDotDot;
        QStringList audioNameFilters ;

        audioNameFilters << QString ("*.m4a") << QString("*.mp3") << QString("*.flac") << QString("*.ogg") << QString("*.wma");
        //rootPath.setFilter(filter);
        QDirIterator dirIter (path,audioNameFilters, filter,QDirIterator::Subdirectories);
        QTime t;
        t.start();
        while(dirIter.hasNext())
        {
            urls.push_back(dirIter.next());
        }
        std::set_difference(urls.begin(), urls.end(),
                            urlsFromDatabase.begin(), urlsFromDatabase.end(),
                            std::inserter(newfileList, newfileList.begin()));
        fetchAndReadTime = t.elapsed();

        qDebug() << "Here is the list of new file : ";
        for(auto it : newfileList)
        {
            qDebug() << " " +  it;
        }

    }
}



void FilePrepare::fetchDirs(QDir &rootPath)
{

    /*
     * This function produce the list of all directories available in
     * rootPath and store that list into dirList.
     * This list will then be used to fill the Database.
     */

    if(rootPath.exists())
    {
        QDir::Filters filter;
        filter = QDir::AllDirs | QDir::NoDotAndDotDot;
        rootPath.setFilter(filter);
        QDirIterator dirIter (rootPath.absolutePath(), filter,QDirIterator::Subdirectories);
        int i = 0;
        while(dirIter.hasNext())
        {
            dirList.push(dirIter.next());
            i++;
        }
        qDebug() << " There are " << i << " directories in " << rootPath.dirName();
    }

    else
    {
        qDebug() << "Directory " + rootPath.dirName() + " doesn't exist" ;
    }

}

void FilePrepare::fetchDirs(QString &path)
{
    //QDir rootpath(path);
    //fetchDirs(rootpath);
    if(QFile::exists(path))
    {
        QDir::Filters filter = QDir::Dirs|QDir::Files | QDir::NoDotAndDotDot;
        QStringList audioNameFilters ;
        audioNameFilters << QString ("*.m4a") << QString("*.mp3") << QString("*.flac") << QString("*.ogg") << QString("*.wma");
        //rootPath.setFilter(filter);
        QDirIterator dirIter (path,audioNameFilters, filter,QDirIterator::Subdirectories);
        int i = 0;
        while(dirIter.hasNext())
        {
            i++;
            newfileList.push_back(dirIter.next().toStdString());
        }
    }

    else
    {
        qDebug() << "Directory " + path + " doesn't exist" ;
    }
}

void FilePrepare::showDirList()
{

        //QString dirName;
        //std::shared_ptr<Utils::TrackTag> track;
        QTime t;
        QString path;
        auto tmp = dirList;
        t.start();
        auto i = tmp.size();
        while(!tmp.empty())
        {
           tmp.try_pop(path);
           //auto track = pathReady.wait_and_pop();

                qDebug() << path;

        }
        auto displayTime = t.elapsed();
        std::cout << "It took " << fetchTime << " msecs to fetch all audiofile"  << std::endl;
        std::cout << "It took " << fetchAndReadTime << " msecs to fetch and read the tag on all audiofile"  << std::endl;
        qDebug() << "It took " << readTagTime << " msecs to read and write the metadata" ;
        qDebug() << "It took " << displayTime << " msecs to display the metadata" ;

        qDebug() << "the container " << " has " << i << " files";



}


void FilePrepare::produceFilesAndReadTag()
{
    if(QFile::exists(path))
    {
        QDir::Filters filter = QDir::Dirs|QDir::Files | QDir::NoDotAndDotDot;
        QStringList audioNameFilters ;
        QString tmppath;
        audioNameFilters << QString ("*.m4a") << QString("*.mp3") << QString("*.flac") << QString("*.ogg") << QString("*.wma");
        QDirIterator dirIter (path,audioNameFilters, filter,QDirIterator::Subdirectories);
        QTime t;
        t.start();
        while(dirIter.hasNext())
        {
            tmppath = dirIter.next();
            tracksReady.push(TestTagReader::tagreader(tmppath));
        }
        fetchAndReadTime = t.elapsed();

    }

}



void FilePrepare::addToDatabase()
{

    database.addToDatabase(tracksReady);

}


void FilePrepare::createPlaylist(QString &playlistName)
{
    database.createPlaylist(playlistName);
}

int FilePrepare::lastAddedDate()
{
    return database.getLastAddedDate();
}

int FilePrepare::lastModifiedDate()
{
    return database.getLastModifiedDate();
}
