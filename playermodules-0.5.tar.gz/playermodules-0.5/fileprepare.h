#ifndef FILEPREPARE_H
#define FILEPREPARE_H

#include "queue.h"
#include "logger.h"
#include "tagreader.h"
#include "utils.h"
#include "album.h"
#include <thread>
#include <QtSql>
#include <QDateTime>
#include <QDir>
#include <memory>
#include <algorithm>
#include <vector>
#include <string>

class FilePrepare
{
public:
    //FilePrepare();
    FilePrepare()
    {
        fileCount = 0;
        tagReadCount = 0;
        readTagTime = 0;
        fetchTime = 0;
        fetchAndReadTime = 0;
        path = QString("/home/cyrildz/Music");
    }

    /* I prevent a copy from this class
     * because std::thread is non-copyable
     */

    FilePrepare(FilePrepare const& ) = delete;
    FilePrepare& operator=(FilePrepare const&) = delete;
    void showDirList();
    void fetchDirs(QDir &rootPath);
    void fetchDirs(QString &path);
    void produceNewFiles();
    void run();
    void produceFilesAndReadTag();
    void addToDatabase();
    void clear();
    void createPlaylist(QString &playlistName);
    int lastAddedDate();
    int lastModifiedDate();

private:


    std::vector<std::string> newfileList;
    Utils::Queue<QString> dirList;
    Utils::Queue<Utils::TrackTag> tracksReady;
    Utils::Queue<Album> albums;
    Utils::Database database;
    int fileCount;
    int tagReadCount;
    int fetchTime;
    int readTagTime;
    int fetchAndReadTime;
    QString path;
    mutable std::mutex fileCountMutex;
    mutable std::mutex updateMutex;
    std::thread updater;
    std::thread producer;
    std::thread display;

};

#endif // FILEPREPARE_H
