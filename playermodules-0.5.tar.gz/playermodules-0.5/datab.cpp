#include "datab.h"


DataB::DataB(QQuickItem *parent):QQuickItem(parent)
{
    sourceDir =  QStandardPaths::locate(QStandardPaths::MusicLocation,"",QStandardPaths::LocateDirectory);
    databaseDir = QDir::homePath()+ "/MyPlayer/Database";
    databaseName =  databaseDir + "/musicDB.db";
    fileName = databaseDir + "/tmpMusicDB.db";
    connectionName = "Update";
    fullUpdate = false;
    startupUdate = true;
    lastmodified = 0; //QDateTime::currentDateTime().toTime_t();

    //connect(this, SIGNAL(directoryDeleted(QList<int>)), this, SLOT(dropAlbum(QList<int>)));
    // I need to first check if there is already on DB or a file with this name in the Config Folder.

    // check to see if MusicDB.db exist .
    // If not , then create a new one and work with it.
    // if yes then populate the playerDB.db with musicDB.db's content.

    if(!QFile::exists(databaseName))
    {
        QSqlDatabase musicDB = QSqlDatabase::addDatabase("QSQLITE",connectionName);
        musicDB.setDatabaseName(fileName);
       // musicDB = QSqlDatabase::database(connectionName);


            if ( musicDB.open())

            {
                QSqlQuery musicQuery = QSqlQuery(musicDB);
                musicQuery.exec(QString("CREATE TABLE Genre"
                                 "("
                                         "genreID INTEGER ,"
                                         "genre TEXT UNIQUE COLLATE NOCASE,"
                                         "PRIMARY KEY(genreID)"
                                 ");"
                                ));

                musicQuery.exec(QString("CREATE TABLE Artist (artistID INTEGER PRIMARY KEY,"
                                "artistname TEXT UNIQUE COLLATE NOCASE );"
                                ));

                // TODO : Add the year Tag, it will offer a better user experience
                musicQuery.exec(QString("CREATE TABLE Album"
                           "("
                               "albumID INTEGER ,"
                               "albumgenreID INTEGER  REFERENCES Genre(genreID),"
                               "title TEXT COLLATE NOCASE,"
                               "albumArtist TEXT COLLATE NOCASE,"
                               "subDirID INTEGER REFERENCES SubDirectories(subDirectoryID),"
                               "coverpath TEXT  COLLATE NOCASE,"
                               "year INTEGER DEFAULT 0,"
                               "PRIMARY KEY (albumID) );"
                            ));

                musicQuery.exec(QString("CREATE TABLE Track"
                           "(trackID INTEGER ,"
                           "trackartistID INTEGER  REFERENCES Arstist(artistID),"
                           "trackalbumID INTEGER REFERENCES Album (albumID),"
                           "title TEXT COLLATE NOCASE,"
                           "album TEXT COLLATE NOCASE,"
                           "artist TEXT COLLATE NOCASE,"
                           "genre TEXT COLLATE NOCASE,"
                           "trackpath TEXT NOT NULL UNIQUE COLLATE NOCASE,"
                           "trackposition INTEGER,"
                           "tracklength INTEGER,"
                           "playcount INTEGER DEFAULT 0,"
                           "liked INTEGER DEFAULT 0,"
                           "bitrate INTEGER,"
                           "year INTEGER DEFAULT 0,"
                           "PRIMARY KEY (trackID) );"
                           ));
                musicQuery.exec(QString("CREATE TABLE Playlist"
                           "("
                               "playlistID INTEGER,"

                               "title TEXT UNIQUE COLLATE NOCASE,"
                               "PRIMARY KEY (playlistID) );"
                            ));
                musicQuery.exec(QString("CREATE TABLE PlaylistTrack"
                           "(playlisttrackID INTEGER ,"
                           "trackID INTEGER REFERENCES Track(trackID),"
                           "trackplaylistID INTEGER REFERENCES PlaylistTrack (playlistID),"
                           //"title TEXT COLLATE NOCASE,"
                           // "trackpath TEXT NOT NULL  COLLATE NOCASE,"
                           //"tracklength INTEGER,"
                           "PRIMARY KEY (playlisttrackID) );"
                           ));
                musicQuery.exec(QString("REPLACE INTO Playlist (title) VALUES('Favorite') ;"));


                // Directory is the Collection source: for example Music, /media/$USER/Music ...

                musicQuery.exec(QString("CREATE TABLE Directories"
                                        "(directoryID INTEGER,"
                                        "path TEXT NOT NULL UNIQUE COLLATE NOCASE,"
                                        "lastScanedDate INTEGER,"
                                        "PRIMARY KEY (directoryID));"));
                //Subdirectory is the content of the collection
                musicQuery.exec(QString("CREATE TABLE SubDirectories"
                                        "(subDirectoryID INTEGER,"
                                        /*"parentID INTEGER REFERENCES Directories(directoryID)," */
                                        "path TEXT NOT NULL UNIQUE COLLATE NOCASE,"
                                        "addedDate INTEGER,"
                                        "modifiedDate INTEGER,"
                                        "PRIMARY KEY (subDirectoryID));"));
                musicQuery.finish();
            }
            //musicDB.removeDatabase(connectionName);
            //database.close();
            musicDB.close();
        }

    else
    {
        databaseLiveUpdate();

    }

    QSqlDatabase::removeDatabase(connectionName);
    startupUdate = false;


}


void DataB::fillDATABASE(const QString &dirPath, QSqlQuery *musicQuery)
{


    // Not very necessary
    QFile query("query.txt"); // for debugging purpose only

    if (!query.open(QIODevice::Append | QIODevice::Text))
            return;
    QTextStream outQuery(&query);

    outQuery.setFieldAlignment(QTextStream::AlignLeft);

    // Query starts here:
    //QString timeString;

    // here starts the code.

    uint addedDate = QDateTime::currentDateTime().toTime_t();
    FileSystemInfo dirInfo (dirPath);
    QStringList filter;
    filter << "*.mp3" <<"*.flac" << "*.ogg" <<"*.wav" << "*.wma" << "*.oga" << "*.aac" << "*.mp4" << "*.m4a" ;
    QDirIterator workingFile (dirPath, filter,QDir::Files | QDir::NoDotAndDotDot);
    musicQuery->exec(QString("INSERT OR REPLACE INTO SubDirectories(path,addedDate,modifiedDate) VALUES('%1','%2','%3');").arg(dirPath,QString::number(addedDate),QString::number(dirInfo.created())));
    int subdirID = musicQuery->lastInsertId().toInt();
    QString coverpath;
    addCover(dirPath,coverpath);
    bool error = true; // For Debugging purpose
    int i = 0;
    TrackTag track;

                    while(workingFile.hasNext())
                    {

                                    // Here starts the tags reading
                                   track = M3UTools::tagreader(workingFile.next());


                                   error = musicQuery->exec(QString("INSERT  INTO Artist (artistname) SELECT '%1' WHERE NOT EXISTS (SELECT 1 FROM Artist WHERE artistname ='%1');").arg(track.artist.replace(QLatin1Char('\''), QLatin1String("''"))));
                                   if (!error)
                                   {
                                       outQuery<<" Last query  Error: " << musicQuery->lastError().text();
                                       outQuery << "Last Querry Command : " << musicQuery->lastQuery();
                                   }


                                   if (i == 0) // I only need to add the Album once. that is why I use this 0.
                                   {
                                       error = musicQuery->exec(QString("INSERT  INTO Genre (genre) SELECT '%1' WHERE NOT EXISTS (SELECT 1 FROM Genre WHERE genre ='%1');").arg(track.genre));
                                       if (!error)
                                       {
                                           outQuery<<" Last query  Error: " << musicQuery->lastError().text()  ;
                                           outQuery << "Last Querry Command : " << musicQuery->lastQuery();
                                       }

                                     // TO DO :: !!!
                                     // I HAVE TO FIND A WAY TO PREVENT FROM ADDING AN ALREADY PRESENT ALBUM
                                     //
                                     error = musicQuery->exec(QString("INSERT INTO Album (albumgenreID,title,albumArtist,subDirID,coverpath,year) VALUES((SELECT genreID FROM Genre WHERE genre='%1'),'%2','%3','%4','%5','%6') ;").arg(track.genre,track.albumTitle.replace(QLatin1Char('\''), QLatin1String("''")),track.artist,QString::number(subdirID),coverpath.replace(QLatin1Char('\''), QLatin1String("''")),QString::number(track.year)));
                                     if (!error)
                                     {
                                         outQuery<<" Last query  Error: " << musicQuery->lastError().text()  ;
                                         outQuery << "Last Querry Command : " << musicQuery->lastQuery();
                                     }



                                   }


                                   qDebug() << "Album : " << track.albumTitle ;

                                   error = musicQuery->exec(QString("INSERT INTO Track (trackartistID,trackalbumID,title,album,artist,genre,trackpath,trackposition,tracklength,bitrate,year)"
                                                           "VALUES((SELECT artistID FROM Artist WHERE artistname='%1'),"
                                                                   "(SELECT albumID FROM Album WHERE title='%2'),'%3','%2','%1', '%4', '%5','%6','%7','%8','%9');").arg(track.artist.replace(QLatin1Char('\''), QLatin1String("''")),track.albumTitle.replace(QLatin1Char('\''), QLatin1String("''")),track.title.replace(QLatin1Char('\''), QLatin1String("''")), track.genre,track.path.replace(QLatin1Char('\''), QLatin1String("''")),QString::number(track.position), QString::number(track.length), QString::number(track.bitRate), QString::number(track.year)));

                                   if (!error)
                                   {
                                       outQuery<<" Last query  Error: " << musicQuery->lastError().text()  ;
                                       outQuery << "Last Querry Command : " << musicQuery->lastQuery();
                                   }

                                    i++;


                    }
                    //dirInfo.setCount(i);

                    //dirInfo.showInfo();


}


void DataB::databaseLiveUpdate()
{

            /**********************************************
             ************ DatabaseLiveUpdate() ************
             ** This code is called when DatabaseManager signal
             ** that the source folder has changed. It get the
             ** date of the last inserted Record in the database
             **  and use this date to repere the new folder and add
             ** it contents into the database.
             ** The next iteration of this code will allow to update
             ** the database for the old folder which only has changed
             **  let say, the user has added a cover or a missed Track
             ** to the album.
             **********************************************
             **********************************************/
            QList<int>deletedDirIDs;
            QStringList dirsToAdd ;
            setChangedDirs(deletedDirIDs,dirsToAdd);
            if(!deletedDirIDs.isEmpty())
            {
                dropAlbum(deletedDirIDs);
            }

            if(!dirsToAdd.isEmpty())
            {
                qDebug()<< "Database Live Update: Here is the list of directories that have changed :";
                Q_FOREACH(const QString &str, dirsToAdd)
               {
                   qDebug()<< str;
               }
            }




            QSqlDatabase musicDB = QSqlDatabase::addDatabase("QSQLITE", "liveUpdate");
            musicDB.setDatabaseName(databaseName);


            if(musicDB.open())
            {
                qDebug()<< "Database opened for live Update";
                QSqlQuery musicQuery = QSqlQuery(musicDB);
                musicQuery.exec("BEGIN TRANSACTION");
                musicQuery.exec("PRAGMA SYNCHRONOUS = OFF");
                musicQuery.exec("PRAGMA journal_mode = MEMORY");
                QTime t;
                t.start();
                QList<int> albumToDrop;
                QStringList albumToAdd;
                for( QStringList::iterator iter = dirsToAdd.begin(); iter!= dirsToAdd.end(); iter++)
                {

                    musicQuery.exec(QString("SELECT albumID FROM Album WHERE subDirID = (SELECT subDirectoryID FROM SubDirectories WHERE path ='%1');").arg(*iter));
                    if(musicQuery.isActive() && musicQuery.isValid())
                    {
                        // the current Dir was just modified since it is in SubDirectories and the query is valide
                        // I drop that. But I need to implement a better code to update the field in album Table

                        if(musicQuery.next())
                        {
                            albumToDrop << musicQuery.value("albumID").toInt();
                        }                      

                    }
                    else
                    {
                        //the query is not valide, the current Dir is not in the DB.
                        // I store it into the list of albums to add.
                        albumToAdd << *iter;
                    }

                }
                dropAlbum(albumToDrop);

                for(QStringList::iterator iter = albumToAdd.begin(); iter!= albumToAdd.end(); iter++)
                {
                    fillDATABASE(*iter,&musicQuery);
                }



                musicQuery.exec("END TRANSACTION");
                musicQuery.finish();
                qDebug()<< dirsToAdd.count()<< "  DatabaseLiveUpdate : Directories scanned. The Scan is over. ";
                qDebug("Time taken to scann the dirs : %d ms", t.elapsed());
                musicDB.close();
            }

            //QSqlDatabase::removeDatabase("liveUpdate");
            Q_EMIT updateJobFinished();
            Q_EMIT databaseChanged();
}

void DataB::updateDATABASE()
{
    // Check if the fullUpdate Flag is checked.
    // If yes, then proceed with a full database update
    // If not then do a partial update (live Update)

    if(fullUpdate)
    {
        // I should opened the Database and set
        if(QFile::exists(databaseName))
           rename(databaseName, databaseName +"-bak");
        // controlling if the Dir exists
        qDebug() << "Full database Update started" ;

        if (QDir(sourceDir).exists())
        {
            QString dirPath;
            QSqlDatabase musicDB = QSqlDatabase::addDatabase("QSQLITE",connectionName);
            musicDB.setDatabaseName(fileName);
            if(musicDB.open())
            {
                QSqlQuery musicQuery = QSqlQuery(musicDB);
                musicQuery.exec("SELECT trackID FROM Track WHERE trackposition = 200");
                musicQuery.finish();
                QTime t;
                QDirIterator dir (sourceDir, QDir::Dirs | QDir::NoDotAndDotDot,QDirIterator::Subdirectories|QDirIterator::FollowSymlinks);
                int i =0;
                t.start();
               musicQuery.exec("BEGIN TRANSACTION");
               musicQuery.exec("PRAGMA SYNCHRONOUS = OFF");
               musicQuery.exec("PRAGMA journal_mode = MEMORY");
                while (dir.hasNext())
                {
                    dirPath = dir.next();

                    fillDATABASE(dirPath,&musicQuery);
                    i++;

                }
                musicQuery.exec("END TRANSACTION");
                musicQuery.finish();
                qDebug()<< i<< " Directories scanned. The Scan is over. ";
                qDebug("Time taken to scann the dirs : %d ms", t.elapsed());
            }
            musicDB.close();

         }
        // time to replace the old Database with the new one
        //remove(databaseName);
        //copy(fileName,databaseName);
        if(rename(fileName,databaseName))
        {
            remove(databaseName + "-bak");
        }

        //QSqlDatabase::removeDatabase(connectionName);

        Q_EMIT updateJobFinished();
        Q_EMIT databaseChanged();
    }

    else
    {
        databaseLiveUpdate();
        fullUpdate = false;
    }


}


void DataB::addCover(const QString &path, QString &cover) // This function doesn't belong to DataB.
{

    //QStringList filters;
    //filters << "*.jpg" << "*.png" << "*.svg";
    //QDirIterator workingDir (path, filters,QDir::Files | QDir::NoDotAndDotDot);
    QDirIterator workingDir (path, QStringList()<< "*.jpeg "<< "*.jpg" << "*.png" << "*.svg",QDir::Files | QDir::NoDotAndDotDot,QDirIterator::Subdirectories);

    if (workingDir.hasNext())
    {

              cover = workingDir.next();

    }

}

void DataB::setSourceDir(QString &path)
{
    sourceDir = QString(path);
    updateDATABASE(); // maybe I need to create a new DB for testing this

}


void DataB::setDatabaseDir(QString dir)
{
    databaseDir = dir;
}

void DataB::setDatabaseName(QString DBname)
{
    databaseName = DBname;
}

QString DataB::getDatabaseDir()const
{
    return databaseDir;
}

QString DataB::getDatabaseName()const
{
    return databaseName;
}


bool DataB::copy(QString newName) const
{
    if(QFile::exists(databaseName))
    {

            QFile::remove(databaseName);
            return QFile::copy(newName, databaseName);
    }
    else
    {
        qDebug()<< "FAIL  To COPY : File " + databaseName << " doesn't exits" ;
        return false;
    }


}

bool DataB::copy(QString oldName, QString newName) const
{
    if(QFile::exists(newName))
    {

            QFile::remove(newName);

    }
    if (QFile::copy(oldName,newName))
    {
        return true;
    }
    else
    {
        qDebug()<< "FAIL  To COPY : File " + databaseName << " doesn't exits" ;
        return false;
    }

}

bool DataB::rename(QString newName) const
{
    if(QFile::exists(databaseName))
    {

           return QFile::rename(databaseName, newName);
    }

    else
    {
        qDebug()<< "FAIL  To RENAME : File " + databaseName << " doesn't exits" ;
        return false;
    }
}

bool DataB::rename(QString oldName, QString newName) const
{
    if(QFile::exists(oldName))
    {

           return QFile::rename(oldName, newName);
    }

    else
    {
        qDebug()<< "FAIL To RENAME : File " + oldName << " doesn't exits" ;
        return false;
    }
}

bool DataB::remove(QString fileName) const
{
    if(QFile::exists(fileName))
    {

           return QFile::remove(fileName);
    }


    else
    {
        qDebug()<< "FAIL To REMOVE : File " + fileName << " doesn't exits" ;
        return false;
    }
}


int DataB::createPlaylist(QString name)
{
    // maybe I should first try to check if the playlist already exits

    QSqlDatabase musicDB = QSqlDatabase::addDatabase("QSQLITE",connectionName);
    musicDB.setDatabaseName(databaseName);
    bool opened = musicDB.open();
    if(opened)
    {
        int id;
        QSqlQuery musicQuery = QSqlQuery(musicDB);
        musicQuery.exec(QString("REPLACE INTO Playlist (title) VALUES('%1') ;").arg(name));
        id = musicQuery.lastInsertId().toInt();
        Q_EMIT playlistsModelChanged();
        //musicQuery.clear();
        musicDB.close();
        return id;
    }
    else
    {
        musicDB.close();
         qDebug() << "DataB::createPlaylist:  Database is not opened";
        return -1; // please check the return value first to know if
    // the operation was succesfull
    }



}

bool DataB::addToPlaylist(int playlistID, int trackID)
{
    QSqlDatabase musicDB = QSqlDatabase::addDatabase("QSQLITE",connectionName);
    musicDB.setDatabaseName(databaseName);
    bool opened = musicDB.open();
    if(opened)
    {
        QSqlQuery musicQuery = QSqlQuery(musicDB);
        musicQuery.exec(QString("INSERT INTO PlaylistTrack (trackID,trackplaylistID) VALUES('%1', '%2') ;").arg(QString::number(trackID),QString::number(playlistID)));
        Q_EMIT playlistsModelChanged();
        musicQuery.finish();
        musicDB.close();
        return true;
    }
    else
    {
        qDebug() << "DataB::addToPlaylist:  Database is not opened";
        return false;
    }
    musicDB.close();

}

bool DataB::removeFromPlaylist(int playlistID, int trackID)
{
    QSqlDatabase musicDB = QSqlDatabase::addDatabase("QSQLITE",connectionName);
    musicDB.setDatabaseName(databaseName);
    bool opened = musicDB.open();
    if(opened)
    {
        QSqlQuery musicQuery = QSqlQuery(musicDB);
        musicQuery.exec(QString("DELETE  * FROM  PlaylistTrack  WHERE trackplaylistID='%1' AND trackID ='%2' ;").arg(QString::number(playlistID),QString::number(trackID)));
        Q_EMIT playlistsModelChanged();
        //musicQuery.clear();
        musicDB.close();
        return true;

     }

    else
    {
        qDebug() << "DataB::removeFromPlaylist:  Database is not opened";
        return false;
    }
}

bool DataB::removePlaylist(int playlistID)
{
    QSqlDatabase musicDB = QSqlDatabase::addDatabase("QSQLITE",connectionName);
    musicDB.setDatabaseName(databaseName);
    bool opened = musicDB.open();
    if(opened)
    {
        QSqlQuery musicQuery = QSqlQuery(musicDB);
        musicQuery.exec("BEGIN TRANSACTION");
        musicQuery.exec(QString("DELETE  * FROM  PlaylistTrack  WHERE trackplaylistID='%1' ;").arg(QString::number(playlistID)));
        musicQuery.exec(QString("DELETE  * FROM  Playlist  WHERE playlistID='%1' ;").arg(QString::number(playlistID)));
        Q_EMIT playlistsModelChanged();
        musicQuery.exec("END TRANSACTION");

        musicQuery.finish();
        musicDB.close();
        Q_EMIT playlistsModelChanged();
        return true;
    }


    else
    {
        qDebug() << "DataB::removePlaylist: Database is not opened";
        return false;
    }
}

QStringList DataB::dirList()const
{
    QSqlDatabase musicDB = QSqlDatabase::addDatabase("QSQLITE",connectionName);
    musicDB.setDatabaseName(databaseName);
    QStringList list;
    if(musicDB.open())
    {

        QSqlQuery dirQuery(musicDB);
        dirQuery.exec("BEGIN TRANSACTION");
        dirQuery.exec("PRAGMA SYNCHRONOUS = OFF");

        dirQuery.exec("PRAGMA journal_mode = MEMORY");
        dirQuery.exec(QString("SELECT * FROM SubDirectories WHERE count > 0;"));
        if(dirQuery.isActive() && dirQuery.isSelect())
        {

            while(dirQuery.next())
            {

                 list << dirQuery.value("path").toString();

            }

            musicDB.close();
            dirQuery.finish();
            //QSqlDatabase::removeDatabase(connectionName);
            return list;
        }
    }


        qDebug() << " DataB::dirList: database not opened";
        return QStringList();

}


void DataB::showDirsList()const
{
    QStringList list(dirList());
    QStringList::Iterator it;

    int i = 0;
   for(it = list.begin(); it != list.end(); it++)
    {

        qDebug() << i++ << " " << *it ;


    }
}


void DataB::dropAlbum(QList<int> &dirs)
{
    QString tmpConnectionName("Drop Directories");
    QSqlDatabase musicDB = QSqlDatabase::addDatabase("QSQLITE",tmpConnectionName);
    musicDB.setDatabaseName(databaseName);

    if(musicDB.open())
    {
        qDebug()<<" Database opened with the connectionName : "  + tmpConnectionName;
        qDebug()<< "Debug DataB::dropAlbum: There are " <<dirs.count() << " that were deleted";
        QSqlQuery albumQuery = QSqlQuery(musicDB);
        QSqlQuery tracksDrop = QSqlQuery(musicDB);

        //QList<int> subDirIDs = dirs;
        QList<int> albumIDs;
        // get the albums' IDs

        //QListIterator<int> subDirIT (dirs);
        QList<int>::iterator subDirIT ;

        albumQuery.exec("BEGIN TRANSACTION");
        albumQuery.exec("PRAGMA SYNCHRONOUS = OFF");
        albumQuery.exec("PRAGMA journal_mode = MEMORY");
        //int i;
        for(subDirIT = dirs.begin(); subDirIT!= dirs.end(); subDirIT++)
        //while (subDirIT++ != dirs->end())
        {
           //i = *subDirIT;
            qDebug()<< "Debug DataB::dropAlbum: subDirectoryID :  " << *subDirIT;
           albumQuery.exec(QString("SELECT albumID FROM Album WHERE subDirID ='%1';").arg(*subDirIT));

           if (albumQuery.isActive() && albumQuery.next())
           {
               int albumID = albumQuery.value("albumID").toInt();
               albumIDs << albumID;
               qDebug()<< "Debug DataB::dropAlbum: subDirectoryID :  " << *subDirIT;
               qDebug()<< "Debug DataB::dropAlbum: albumID :  " << albumID;
               tracksDrop.exec(QString("DELETE FROM Track WHERE trackalbumID ='%1';").arg(albumID));
               albumQuery.exec(QString("DELETE FROM Album WHERE albumID ='%1';").arg(albumID));
           }
           albumQuery.exec(QString("DELETE FROM SubDirectories WHERE subDirectoryID ='%1';").arg(*subDirIT));
           // need to update the playlist Table too.
           //subDirIT++;
        }
        qDebug()<<albumIDs.count() << " albums Deleted";
        albumQuery.exec("END TRANSACTION");
        albumQuery.finish();
        tracksDrop.finish();
        musicDB.close();
        //QSqlDatabase::removeDatabase(tmpConnectionName);
    }

    else
    {
        qDebug()<<" Database could not be opened with the connectionName : "  + tmpConnectionName;
    }

}

void DataB::updateAlbum(int albumID, QString &dirPath)
{

    // TO DO
}

QStringList DataB::changedDirs(QList<int> *deletedDirs)
{

    QStringList changedDirectories;
    QStringList newDirectories;
    uint latestDate = 0, oldDate = 0;

    qDebug() << " Debug DataB::changedDirs: Latest Date first Test: " << QDateTime::fromTime_t(latestDate);
    qDebug() << " Debug DataB::changedDirs: Latest Date first Test (in Seconds): " << latestDate;
    qDebug() << " Debug DataB::changedDirs: Latest Date first Test (Normal): " << QDateTime::fromString(QString("1970-01-01T00:00:00"),Qt::ISODate);
    qDebug() << " Debug DataB::changedDirs: Current Date: " << QDateTime::currentDateTime().toTime_t();

    if(startupUdate)
    {
        // open the the Database an the date we added the last album
        QString tmpConnectionName("Scann Directories");
        QSqlDatabase musicDB = QSqlDatabase::addDatabase("QSQLITE",tmpConnectionName);
        musicDB.setDatabaseName(databaseName);
        if(musicDB.open())
        {
            qDebug()<<" Database opened with the connectionName : "  + tmpConnectionName;
            QSqlQuery musicQuery = QSqlQuery(musicDB);
            musicQuery.exec("BEGIN TRANSACTION");
            musicQuery.exec("PRAGMA SYNCHRONOUS = OFF");
            musicQuery.exec("PRAGMA journal_mode = MEMORY");
            musicQuery.exec(QString("SELECT * FROM SubDirectories ORDER BY subDirectoryID;"));
            if(musicQuery.isActive())
            {
                qDebug()<< "Debug DataB::changedDirs: musicQuery is active ";
                while (musicQuery.next())
                {
                    // get the modifiedDate field
                    // get the list of deleted directories too

                     //qDebug()<< "Debug DataB::changedDirs: deleted Dir :  " << path << dir.exists();
                     if(!QDir(musicQuery.value("path").toString()).exists())
                     {
                        //qDebug()<< "Debug DataB::changedDirs: deleted Dir :  " << path << dir.exists();
                        deletedDirs->append( musicQuery.value("subDirectoryID").toInt());
                     }
                     else
                     {
                         // Here I will check if we have new dirs as well as changed dirs
                         // First : I get the news dirs


                             // start the scann since we lastly added or changed an album:
                             oldDate = QDateTime::fromTime_t( musicQuery.value("addedDate").toInt()).toTime_t();
                             if(latestDate > oldDate)
                                 ;
                             else latestDate = oldDate;

                     }

                }
                qDebug() << " Debug DataB::changedDirs: Latest Date Final: " << QDateTime::fromTime_t(latestDate);
                qDebug() << " Debug DataB::changedDirs: Latest Date Final Test (in Seconds): " << latestDate;
            }

            /* DatabaseLiveUpdate() is called everytime
             * QFileSystemWatcher emit a directoryChanged signal.
             * If there are many changes in a short period of time,
             * not all changes will be sent.
             * So, to be sure I get all the new files,
             * I wait for 1min before starting scanning the source.
             * For That I use a Timer.
             */

            musicQuery.exec("END TRANSACTION");
            musicQuery.finish();
            musicDB.close();
        }

        else
        {
            qDebug()<<" Database could not be opened with the connectionName : "  + tmpConnectionName;
            return QStringList();
        }
    }

    else
    {
        // we do normal live update, that is, since the signal was emited , so , since now.

        latestDate = QDateTime::currentDateTime().toTime_t();

    }


    changedDirectories = FileSystemInfo::folderLaterThan(sourceDir,QDateTime::fromTime_t( latestDate));
    qDebug()<< "Debug DataB::changedDirs: There are " <<changedDirectories.count() << " that have changed";
    qDebug()<< "Debug DataB::changedDirs: There are " <<deletedDirs->count() << " that were deleted";
    qDebug() << "Debug DataB::changedDirs: list of dir that have changed since :"  << QDateTime::fromTime_t(latestDate);
    Q_FOREACH(const QString &str, changedDirectories)
    {
        qDebug()<< str;
        qDebug() <<" Folder Infos :";
        FileSystemInfo(str).showInfo();

    }

    //Q_EMIT directoryDeleted(deletedDirs);
    return QStringList(changedDirectories);



}

QList<int> DataB::deletedFolder()
{

        // open the the Database an the date we added the last album
        QString tmpConnectionName("Scann Directories");
        QList<int> deletedDirs;
        uint oldDate = 0;
        QSqlDatabase musicDB = QSqlDatabase::addDatabase("QSQLITE",tmpConnectionName);
        musicDB.setDatabaseName(databaseName);
        if(musicDB.open())
        {
            qDebug()<<" Database opened with the connectionName : "  + tmpConnectionName;
            QSqlQuery musicQuery = QSqlQuery(musicDB);
            musicQuery.exec("BEGIN TRANSACTION");
            musicQuery.exec("PRAGMA SYNCHRONOUS = OFF");
            musicQuery.exec("PRAGMA journal_mode = MEMORY");
            musicQuery.exec(QString("SELECT * FROM SubDirectories ORDER BY subDirectoryID;"));
            if(musicQuery.isActive())
            {
                qDebug()<< "Debug DataB::changedDirs: musicQuery is active ";
                while (musicQuery.next())
                {
                    // get the modifiedDate field
                    // get the list of deleted directories too

                     //qDebug()<< "Debug DataB::changedDirs: deleted Dir :  " << path << dir.exists();
                     if(!QDir(musicQuery.value("path").toString()).exists())
                     {
                        //qDebug()<< "Debug DataB::changedDirs: deleted Dir :  " << path << dir.exists();
                        deletedDirs.append( musicQuery.value("subDirectoryID").toInt());
                     }
                     else
                     {
                         // Here I will check if we have new dirs as well as changed dirs
                         // First : I get the news dirs


                             // start the scann since we lastly added or changed an album:
                             oldDate = QDateTime::fromTime_t( musicQuery.value("modifiedDate").toInt()).toTime_t();
                             if(lastmodified > oldDate)
                                 ;
                             else lastmodified = oldDate;

                     }

                }
                qDebug() << " Debug DataB::changedDirs: Latest Date Final: " << QDateTime::fromTime_t(lastmodified);
                qDebug() << " Debug DataB::changedDirs: Latest Date Final Test (in Seconds): " << lastmodified;
            }

            /* DatabaseLiveUpdate() is called everytime
             * QFileSystemWatcher emit a directoryChanged signal.
             * If there are many changes in a short period of time,
             * not all changes will be sent.
             * So, to be sure I get all the new files,
             * I wait for 10s before starting scanning the source.
             * For That I use a Timer.
             */

            musicQuery.exec("END TRANSACTION");
            musicQuery.finish();
            musicDB.close();
        }

        else
        {
            qDebug()<<" Database could not be opened with the connectionName : "  + tmpConnectionName;
            return QList<int>();
        }

    return QList<int>(deletedDirs) ;
}

void DataB::updateAlbumPlayDate(int albumID)
{
    QSqlQuery trackQuery = QSqlQuery(QSqlDatabase::database(connectionName));
    trackQuery.exec(QString("UPDATE Album SET lastplayedDate = '%1' + 1 WHERE albumID ='%2';" ).arg(QDateTime::currentDateTime().toTime_t(),albumID));
    trackQuery.finish();
    Q_EMIT databaseChanged();
}


void DataB::playcountUP(int trackID)
{
    QSqlQuery trackQuery = QSqlQuery(QSqlDatabase::database(connectionName));
    trackQuery.exec(QString("UPDATE Track SET playcount = playcount + 1 WHERE trackID ='%1';" ).arg(trackID));
    trackQuery.finish();
    Q_EMIT databaseChanged();
}


void DataB::updateAlbums(QStringList &paths)
{
    QSqlDatabase musicDB = QSqlDatabase::addDatabase("QSQLITE","UpdateAlbums" );
    
    QSqlQuery albumQuery = QSqlQuery(musicDB);
    
}


void DataB::setChangedDirs(QList<int> &deletedDirs, QStringList &modifiedDirs)
{
    // open the the Database an the date we added the last album
    QString tmpConnectionName("Changed Directories");
    uint oldDate = 0;
    QSqlDatabase musicDB = QSqlDatabase::addDatabase("QSQLITE",tmpConnectionName);
    musicDB.setDatabaseName(databaseName);
    if(musicDB.open())
    {
        qDebug()<<" Database opened with the connectionName : "  + tmpConnectionName;
        QSqlQuery musicQuery = QSqlQuery(musicDB);
        musicQuery.exec("BEGIN TRANSACTION");
        musicQuery.exec("PRAGMA SYNCHRONOUS = OFF");
        musicQuery.exec("PRAGMA journal_mode = MEMORY");
        musicQuery.exec(QString("SELECT * FROM SubDirectories ORDER BY subDirectoryID;"));
        if(musicQuery.isActive())
        {
            qDebug()<< "Debug DataB::changedDirs: musicQuery is active ";
            while (musicQuery.next())
            {
                // get the modifiedDate field
                // get the list of deleted directories too

                 //qDebug()<< "Debug DataB::changedDirs: deleted Dir :  " << path << dir.exists();
                 if(!QDir(musicQuery.value("path").toString()).exists())
                 {
                    //qDebug()<< "Debug DataB::changedDirs: deleted Dir :  " << path << dir.exists();
                    deletedDirs.append( musicQuery.value("subDirectoryID").toInt());
                 }
                 else
                 {
                     // Here I will check if we have new dirs as well as changed dirs
                     // First : I get the news dirs
                        if(startupUdate)
                        {

                            // start the scann since we lastly added or changed an album:
                            oldDate = QDateTime::fromTime_t( musicQuery.value("modifiedDate").toInt()).toTime_t();
                            if(lastmodified > oldDate)
                                ;
                            else lastmodified = oldDate;

                        }

                 }

            }

        }

        if(!startupUdate)
        {
            lastmodified = QDateTime::currentDateTime().toTime_t() - 11;
        }
        qDebug() << " Debug DataB::changedDirs: Latest Date Final: " << QDateTime::fromTime_t(lastmodified);
        qDebug() << " Debug DataB::changedDirs: Latest Date Final Test (in Seconds): " << lastmodified;
        /* Now that I got the Ids of the deleted Dirs, I'm looking
         * for all the new dirs into the source Folder
         * remember that for Qt, the QFileInfo.created() and
         * QFileInfo.lastModified() are the same on most unix system.
         */

        modifiedDirs = FileSystemInfo::folderLaterThan(sourceDir, lastmodified);
        musicQuery.exec("END TRANSACTION");
        musicQuery.finish();
        musicDB.close();
        if(startupUdate)
        {
            startupUdate = false;
        }
    }

    else
    {
        qDebug()<<" Database could not be opened with the connectionName : "  + tmpConnectionName;
    }
}

void DataB::addAlbums(QStringList &paths)
{
    QSqlQuery musicQuery = QSqlQuery(QSqlDatabase::database(connectionName));
    for(QStringList::iterator iter = paths.begin(); iter!= paths.end(); iter++)
    {
        fillDATABASE(*iter,&musicQuery);
    }
}
