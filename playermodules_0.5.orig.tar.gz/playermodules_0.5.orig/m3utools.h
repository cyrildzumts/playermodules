#ifndef M3UTOOLS_H
#define M3UTOOLS_H

#include <QFileInfo>
#include <QFile>
#include <QDir>
#include <QDirIterator>
// Taglib headers file
#include <taglib.h>
#include <tag.h>
#include <id3v2tag.h>
#include <id3v1tag.h>
#include <taglib/fileref.h>
#include <mpegfile.h> // for MPEG::File
#include <asffile.h> // WMA::File
#include <flacfile.h> // FLAC::File
#include <mp4file.h>
#include <oggfile.h>
#include <vorbisfile.h>
#include <oggflacfile.h>
#include <vorbisproperties.h>


#include <QStringList>
#include <QTextStream>
#include "Types.h"
#include <QDebug>

//ID3 LIB headers
#include <id3/tag.h>
#include <id3/misc_support.h>
#include <QDir>

typedef QList <TrackTag> TagList;
namespace M3UTools
{

     void tagreader(TagList *sameTag, TagList *diffTag, QDir parent);
     TrackTag tagreader( QString file);
     TrackTag tagreaderTAGLIB( QString file);
     TrackTag tagreaderFLAC(QString file);
     TrackTag tagreaderMPEG(QString file);
     TrackTag tagreaderOGG(QString file);
     TrackTag tagreaderMP4(QString file);
     TrackTag tagreaderWMA(QString file);
     // Testing ID3
     TrackTag tagreaderID3LIB(QString file);
     QStringList readM3U(QString pls);
     bool writeM3U(QString playlistName, QString audioFile);
     bool writeM3U(QString playlistName, QStringList audioFiles);
    // TO DO :
    // bool removeTrack(QString playlistname, int index);
    // bool removeTrack(QString playlistname, QList<int> indexes);
     bool createM3UFile(QString filename);
     QString M3UPlaylistName(QString file);
     QString cover(QString audioFile);

     // FRAME IDs for ID3Lib :




}

#endif // M3UTOOLS_H
