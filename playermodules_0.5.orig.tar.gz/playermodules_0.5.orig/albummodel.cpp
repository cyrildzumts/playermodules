#include "albummodel.h"

AlbumModel::AlbumModel(QObject *parent):QAbstractListModel(parent)
{
    configPath = QDir::homePath() + "/.Player/config";
    databaseName = configPath + "/player.db";
    //queryString = QString("SELECT * FROM Album JOIN Artist USING (artistID) JOIN Genre USING(genreID) JOIN Cover USING(coverID) ORDER BY albumTitle;");
    queryString = QString("SELECT albumTitle,albumArtist as artistname,genre,cover as coverpath,COUNT(albumTitle) as tracks ,SUM(length) as duration , year FROM BaseTableTracks GROUP BY albumTitle ORDER BY albumTitle;");
    connectionName  = "Logger";
    driver = QString("QSQLITE");
//    database = QSqlDatabase::addDatabase(driver,connectionName);
//    database.setDatabaseName(databaseName);
//    database.open();
//    setQuery(queryString,database);
    QLocale::setDefault(QLocale(QLocale::AnyLanguage));
}


void AlbumModel::refresh()
{
        QSqlDatabase db;
        db = QSqlDatabase::database(connectionName);
        //db.setDatabaseName(databaseName);
        Utils::Album album;
        //albumList.clear();
        resetInternalData();
        if(db.isOpen())
        {
            QSqlQuery albumQuery = QSqlQuery(db);
            //qDebug()<< "AlbumModel::refresh() Database opened:";
            albumQuery.exec(queryString);
            if(albumQuery.isActive())
            {
                //qDebug()<< "AlbumModel::refresh() albumQuery is active:";
                while(albumQuery.next())
                {
                    //album.albumID = albumQuery.value("albumID").toInt();
                    //album.artistID = albumQuery.value("artistID").toInt();
                    //album.coverID = albumQuery.value("coverID").toInt();
                    //album.genreID = albumQuery.value("genreID").toInt();
                    album.duration = albumQuery.value("duration").toInt();
                    album.albumTitle = albumQuery.value("albumTitle").toString();
                    album.tracks = albumQuery.value("tracks").toInt();
                    album.year = albumQuery.value("year").toInt();
                    album.albumArtist = albumQuery.value("artistname").toString();
                    album.genre = albumQuery.value("genre").toString();
                    album.coverpath = albumQuery.value("coverpath").toString();
                    beginInsertRows(QModelIndex(), rowCount(), rowCount());
                    albumList.push_back(album);
                    endInsertRows();
                    //qDebug() << "AlbumModel::refresh(): "  << album.albumTitle  << " - "  << album.tracks  << " tracks.";
                }
                //Q_EMIT dataChanged();

            }
//            else
//            {
//                //qDebug() << "debugQuery is not active";
//            }
            albumQuery.finish();
            //db.close();
        }
}

void AlbumModel::debug()
{
    qDebug() << "AlbumModel::debug()";
    for(Utils::Album album : albumList)
    {
        qDebug() << " Title : " << album.albumTitle + " - Tracks : " << album.tracks;
    }

    qDebug()<<"AlbumModel::debug() - Number of Albums: " << rowCount();

}
QVariant AlbumModel::data2(const QModelIndex &index, int role) const
{
//        query().exec();
//        query().seek(index.row());
//                if(index.row() < 0 || index.row() >= rowCount())
//                    return QVariant();

//                else
//                {
//                    if(query().isActive())
//                    {
//                        qDebug()<< "AlbumModel::data2";
//                        switch (role)
//                        {

//                        case AlbumTitleRole:
//                        {
//                             return query().value("albumTitle").toString().toLatin1();
//                        }
//                        case CoverpathRole:
//                            return query().value("coverID").toInt();
//                        case ArtistRole:
//                            return query().value("artistID").toInt();
//                        case YearRole:
//                            return query().value("year").toInt();
//                        case IDRole:
//                           return query().value("albumID").toInt();
//                        case DurationRole:
//                           return query().value("duration").toInt();
//                        case TracksRole:
//                            return query().value("tracks").toInt();
//                        case GenreIDRole:
//                            return query().value("genreID").toInt();
//                        default:
//                            return QVariant();
//                            break;
//                        }
//                    }
//                }
}


QVariant AlbumModel::data(const QModelIndex &index, int role) const
{

    // Version 3.
        Utils::Album album = albumList.at(index.row());
       // qDebug () << "AlbumModel::data(): succes . Album ID :" << album.albumID;
       //qDebug () << "AlbumModel::data(): Role = :" << role;
       // qDebug () << "AlbumModel::data(): Row :" << index;
        if(index.row() < 0 || index.row() >= rowCount())
            return QVariant();

        else
        {
            switch (role)
            {

            case AlbumTitleRole:
            {
                 return album.albumTitle;
            }
            case CoverpathRole:
                return album.coverpath;
            case ArtistRole:
                return album.albumArtist;
            case YearRole:
                return album.year;
            case IDRole:
               return album.albumID;
            case DurationRole:
               return album.duration;
            case TracksRole:
                return album.tracks;
            case GenreIDRole:
                return album.genreID;
            default:
                return QVariant();
                break;
            }
        }
}

 QHash<int,QByteArray> AlbumModel::roleNames() const
{
       QHash<int, QByteArray> roles;
       roles[AlbumTitleRole] = "title";
       roles[CoverpathRole] = "coverpath";
       roles[ArtistRole]  = "artist";
       roles[YearRole]  = "year";
       roles[IDRole] = "albumID";
       roles[TracksRole] ="tracks";
       roles[DurationRole] = "duration";
       roles[GenreIDRole] = "genreID";
       return roles;
}

 int AlbumModel::rowCount(const QModelIndex &parent) const
 {   
     return albumList.size();
 }


 QString AlbumModel::getQueryText()const
 {
     return queryString;
 }



 void AlbumModel::resetInternalData()
 {
     beginResetModel();
     albumList.clear();
     endResetModel();
     //Q_EMIT dataChanged();
 }
