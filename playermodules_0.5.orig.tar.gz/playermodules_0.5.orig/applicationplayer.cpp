#include "applicationplayer.h"

ApplicationPlayer::ApplicationPlayer(QObject *parent):QObject(parent)
{
    _playbackMode = Playlist::PlaybackMode::Sequential;
    _playlist = new Playlist();
    _albumContents = new TrackListModel(parent);
    _allTrackModel = new TrackListModel(parent);
    _albumModel = new AlbumModel(parent);


    // Connect signals from Database
    connect(&_database,SIGNAL(scanSourceDirectoryFinished()),&_database,SLOT(setup()));
    connect(&_database,SIGNAL(updateJobFinished()),_albumModel,SLOT(refresh()));
   // connect(&_database,SIGNAL(updateJobFinished()),_allTrackModel,SLOT(refresh()));
    //connect(&_database,SIGNAL(setupFinished()),_allTrackModel,SLOT(refresh()));
    connect(&_database,SIGNAL(setupFinished()),_albumModel,SLOT(refresh()));

    //Connect signals from Playlist
    connect(_playlist,SIGNAL(nomedia()),&_player,SLOT(stop()));
    connect(_playlist, SIGNAL(currentIndexChanged(int)),this,SIGNAL(currentIndexChanged(int)));
    connect(_playlist,SIGNAL(dataChanged()),this,SIGNAL(playlistDataChanged()));
    connect(_playlist,SIGNAL(playbackModeChanged(int)),this,SIGNAL(playbackModeChanged(int)));
    connect(_playlist,SIGNAL(playbackModeChanged()),this,SIGNAL(playbackModeChanged()));
    connect(_playlist,SIGNAL(titleChanged(QString)),this,SIGNAL(playingTitleChanged(QString)));
    connect(_playlist,SIGNAL(coverChanged(QString)),this,SIGNAL(coverChanged(QString)));
    connect(this, SIGNAL(currentIndexChanged(int)),this,SLOT(setCurrentMedia(int)));
    //connect(&_player,SIGNAL(stateChanged(QMediaPlayer::State)),this,SLOT(goNext(QMediaPlayer::State)));
    connect(&_player,SIGNAL(mediaStatusChanged(QMediaPlayer::MediaStatus)),this,SLOT(goNext(QMediaPlayer::MediaStatus)));
    scanSourceDirectory();



}

ApplicationPlayer::~ApplicationPlayer()
{
    delete _playlist;
    delete _albumContents;
    delete _allTrackModel;
    delete _albumModel;

}

void ApplicationPlayer::goNext(QMediaPlayer::MediaStatus status)
{
    if(status == QMediaPlayer::EndOfMedia)
        next();
    if (status == QMediaPlayer::InvalidMedia)
    {
        qDebug()<< "DEBUG ApplicationPlayer::player : InvalidMedia";
    }
}

void ApplicationPlayer::setCurrentMedia(int index)
{
    _player.setMedia(_playlist->media(index));
    play();
}

void ApplicationPlayer::setCurrentMedia(QString url)
{
    _player.setMedia(url);
}

void ApplicationPlayer::setAsPlaylist(int index)
{
    qDebug() << "Application::SetAsPlaylist() get called";
    _playlist->setTracklist(_albumContents->tracklist());
    _playlist->setCurrentIndex(index);
    //_albumContents->reset();

}

TrackListModel *ApplicationPlayer::albumContents()
{
    return _albumContents;
}

AlbumModel *ApplicationPlayer::albumsModel()
{
    return _albumModel;
}

Playlist *ApplicationPlayer::playlist()
{
    return _playlist;
}

//GenreModel &ApplicationPlayer::genreModel()
//{
//    return _genreModel;
//}

//PlaylistModel &ApplicationPlayer::playlistModel()
//{
//    return _playlistModel;
//}

TrackListModel *ApplicationPlayer::allTrackModel()
{
    return _allTrackModel;
}

int ApplicationPlayer::playbackMode()
{
    return _playbackMode;
}


// Player Interface definitions :

void ApplicationPlayer::play()
{
    if(_player.state() == QMediaPlayer::PlayingState)
        _player.pause();
    else if((_player.state() == QMediaPlayer::PausedState) || (_player.state() == QMediaPlayer::StoppedState))
        _player.play();
}

void ApplicationPlayer::next()
{
    _playlist->next();
}

void ApplicationPlayer::previous()
{
    if(_player.position() < 5000)
        _playlist->previous();
    else
        _player.setPosition(0);
}

void ApplicationPlayer::stop()
{
    if(_player.state() != QMediaPlayer::StoppedState)
        _player.stop();
}

void ApplicationPlayer::pause()
{
    if(_player.state() == QMediaPlayer::PlayingState)
        _player.pause();
}


void ApplicationPlayer::setMedia(QString &path)
{
    _player.setMedia(path);
}

void ApplicationPlayer::setCover(QString &path)
{
    _playlist->setCover(path);
}

QString ApplicationPlayer::cover()const
{
    return _playlist->cover();
}

void ApplicationPlayer::setTracklist(std::vector<Utils::TrackTag> tracks)
{
    _playlist->setTracklist(tracks);
}

int ApplicationPlayer::currentIndex()const
{
    return _playlist->currentIndex();
}

void ApplicationPlayer::setCurrentIndex(int index)
{
    _playlist->setCurrentIndex(index);
}

void ApplicationPlayer::clearPlaylist()
{
    _playlist->clear();
}

QString ApplicationPlayer::playingTitle()const
{
    return _playlist->title();
}

void ApplicationPlayer::setPlayingTitle(QString t)
{
    _playlist->setTitle(t);
}

void ApplicationPlayer::addMedia(std::vector<Utils::TrackTag> tracks)
{
    _playlist->addMedia(tracks);
}

void ApplicationPlayer::addMedia(Utils::TrackTag track)
{
    _playlist->addMedia(track);
}


QString ApplicationPlayer::currentMedia()const
{
    return _playlist->currentMedia();
}

bool ApplicationPlayer::isEmpty()const
{
    return _playlist->isEmpty();
}

void ApplicationPlayer::insertMedia(int pos, std::vector<Utils::TrackTag> track)
{
    _playlist->insertMedia(pos,track);
}

void ApplicationPlayer::insertMedia(int pos, Utils::TrackTag track)
{
    _playlist->insertMedia(pos,track);
}

QString ApplicationPlayer::media() const
{
    return _playlist->media();
}

QString ApplicationPlayer::media(int index) const
{
    return _playlist->media(index);
}

int ApplicationPlayer::mediaCount()const
{
    return _playlist->mediaCount();
}

bool ApplicationPlayer::removeMedia(int pos)
{
    return _playlist->removeMedia(pos);
}

bool ApplicationPlayer::removeMedia(int start, int end)
{
    return _playlist->removeMedia(start,end);
}

void ApplicationPlayer::save(const QUrl &location, const char *format)
{
    _playlist->save(location,format);
}

void ApplicationPlayer::save(QIODevice *device, const char *format)
{
    _playlist->save(device,format);
}


void ApplicationPlayer::shuffle()
{
    _playlist->shuffle();
}

void ApplicationPlayer::repeat()
{
    _playlist->repeat();
}



// AlbumModel's Interface
void ApplicationPlayer::albumModelrefresh()
{
    _albumModel->refresh();
}


// TracklistModel's Interface
void ApplicationPlayer::trackllistModelReset()
{
    _albumContents->reset();
}

void ApplicationPlayer::trackllistModelSetSourceID(int ID)
{
    _albumContents->setSourceID(ID);
}

int ApplicationPlayer::trackllistModelSourceID()
{
    return _albumContents->sourceID();
}

 std::vector<Utils::TrackTag> ApplicationPlayer::tracklistModelTracklist()
{
    return _albumContents->tracklist();
}


 // Database's Interface

 void ApplicationPlayer::scanSourceDirectory()
 {
     _database.scanSourceDirectory();
     _albumModel->refresh();
 }

 void ApplicationPlayer::addToPlaylist(int trackID, int playlistID)
 {
     _database.addToPlaylist(trackID,playlistID);
 }

 void ApplicationPlayer::addToPlaylist(int trackID, QString playlist)
 {
     _database.addToPlaylist(trackID,playlist);
 }

 int ApplicationPlayer::createPlaylist(QString &playlistName)
 {
     return _database.createPlaylist(playlistName);
 }

 void ApplicationPlayer::removePlaylist(int playlistID)
 {
     _database.removePlaylist(playlistID);
 }

 void ApplicationPlayer::removePlaylist(QString &playlistName)
 {
     _database.removePlaylist(playlistName);
 }

 void ApplicationPlayer::update()
 {
     _database.update();
 }

 void ApplicationPlayer::playCountUp(int trackID)
 {
     _database.playCountUp(trackID);
 }

 void ApplicationPlayer::addToFavorite(int trackID)
 {
     _database.addToFavorite(trackID);
 }

 int ApplicationPlayer::getLastAddedDate()
 {
     return _database.getLastAddedDate();
 }

 int ApplicationPlayer::getLastModifiedDate()
 {
     return _database.getLastModifiedDate();
 }

 void ApplicationPlayer::setup()
 {
     _database.setup();
 }

 std::vector<QString> ApplicationPlayer::getTrackUrls()
 {
     return _database.getTrackUrls();
 }
