#include "updatedb.h"

UpdateDB::UpdateDB(QObject *parent) :
    QObject(parent)
{
}



void UpdateDB::updateDATABASE()
{
    // I should opened the Database and set
    if(QFile::exists(databaseName))
       rename(databaseName, databaseName +"-bak");
    // controlling if the Dir exists

    if (QDir(sourceDir).exists())
    {
        QSqlDatabase musicDB = QSqlDatabase::addDatabase("QSQLITE",connectionName);
        musicDB.setDatabaseName(fileName);
        if(musicDB.open())
        {
            QSqlQuery musicQuery = QSqlQuery(musicDB);
            musicQuery.exec("SELECT trackID FROM Track WHERE trackposition = 200");
            //musicQuery.finish();
            QTime t;
            QDirIterator dir (sourceDir, QDir::Dirs | QDir::NoDotAndDotDot,QDirIterator::Subdirectories|QDirIterator::FollowSymlinks);
            int i =0;
            t.start();
            musicQuery.exec("BEGIN TRANSACTION");
            musicQuery.exec("PRAGMA SYNCHRONOUS = OFF");
            musicQuery.exec("PRAGMA journal_mode = MEMORY");

            musicQuery.exec("SELECT trackID FROM Track WHERE trackposition = 2");
            while (dir.hasNext())
            {
                fillDATABASE(dir.next(),&musicQuery);
                i++;

            }
            musicQuery.exec("END TRANSACTION");
            musicQuery.finish();
            qDebug()<< i<< " Directories scanned. The Scan is over. ";
            qDebug("Time taken to scann the dirs : %d ms", t.elapsed());
        }
        musicDB.close();

     }
    // time to replace the old Database with the new one
    copy(fileName,databaseName);
    remove(fileName);
    //QSqlDatabase::removeDatabase(connectionName);
    Q_EMIT databaseChanged();

}


void UpdateDB::fillDATABASE(const QString &dirPath, QSqlQuery *musicQuery)
{


    QFile query("query.txt"); // for debugging purpose only

    if (!query.open(QIODevice::Append | QIODevice::Text))
            return;
    QTextStream outQuery(&query);

    outQuery.setFieldAlignment(QTextStream::AlignLeft);

    // Query starts here:

    QStringList filter;
    filter << "*.mp3" <<"*.flac" << "*.ogg" <<"*.wav" << "*.wma" << "*.oga" << "*.aac" << "*.mp4" << "*.m4a" ;
    QDirIterator workingFile (dirPath, filter,QDir::Files | QDir::NoDotAndDotDot);

        QString coverpath;
        addCover(dirPath,coverpath);
// I should create my Database variable here
        //QSqlDatabase musicDB = QSqlDatabase::database(connectionName);
        //musicDB.setDatabaseName(fileName);
        //bool ok = musicDB.open();
        bool error = true; // For Debugging purpose


               // if (ok)
                //{
                    //QSqlQuery musicQuery = QSqlQuery(musicDB);
                    int i = 0;
                    TrackTag track;
                    //musicQuery.exec("BEGIN TRANSACTION");
                    while(workingFile.hasNext())
                    {

                                    // Here starts the tags reading
                                   track = M3UTools::tagreader(workingFile.next());
                                   error = musicQuery->exec(QString("REPLACE INTO Artist (artistname) SELECT '%1' WHERE NOT EXISTS (SELECT 1 FROM Artist WHERE artistname ='%1');").arg(track.artist.replace(QLatin1Char('\''), QLatin1String("''"))));
                                   if (!error)
                                   {
                                       outQuery<<" Last query  Error: " << musicQuery->lastError().text();
                                       outQuery << "Last Querry Command : " << musicQuery->lastQuery();
                                   }


                                   if (i == 0) // I only need to add the Album once. that is why I use this 0.
                                   {
                                       error = musicQuery->exec(QString("REPLACE INTO Genre (genre) SELECT '%1' WHERE NOT EXISTS (SELECT 1 FROM Genre WHERE genre ='%1');").arg(track.genre));
                                       if (!error)
                                       {
                                           outQuery<<" Last query  Error: " << musicQuery->lastError().text()  ;
                                           outQuery << "Last Querry Command : " << musicQuery->lastQuery();
                                       }

                                     // TO DO :: !!!
                                     // I HAVE TO FIND A WAY TO PREVENT FROM ADDING AN ALREADY PRESENT ALBUM
                                     //
                                     error = musicQuery->exec(QString("REPLACE INTO Album (albumgenreID,title,albumArtist,coverpath,year) VALUES((SELECT genreID FROM Genre WHERE genre='%1'),'%2','%3','%4','%5') ;").arg(track.genre,track.albumTitle.replace(QLatin1Char('\''), QLatin1String("''")),track.artist,coverpath.replace(QLatin1Char('\''), QLatin1String("''")),QString::number(track.year)));
                                     if (!error)
                                     {
                                         outQuery<<" Last query  Error: " << musicQuery->lastError().text()  ;
                                         outQuery << "Last Querry Command : " << musicQuery->lastQuery();
                                     }

                                     i++;

                                   }


                                   qDebug() << "Album : " << track.albumTitle ;

                                   error = musicQuery->exec(QString("REPLACE INTO Track (trackartistID,trackalbumID,title,trackpath,trackposition,tracklength)"
                                                           "VALUES((SELECT artistID FROM Artist WHERE artistname='%1'),"
                                                                   "(SELECT albumID FROM Album WHERE title='%2'),'%3','%4','%5', '%6');").arg(track.artist.replace(QLatin1Char('\''), QLatin1String("''")),track.albumTitle.replace(QLatin1Char('\''), QLatin1String("''")),track.title.replace(QLatin1Char('\''), QLatin1String("''")),track.path.replace(QLatin1Char('\''), QLatin1String("''")),QString::number(track.position), QString::number(track.length)));

                                   if (!error)
                                   {
                                       outQuery<<" Last query  Error: " << musicQuery->lastError().text()  ;
                                       outQuery << "Last Querry Command : " << musicQuery->lastQuery();
                                   }





                    }
                    //musicQuery.exec("END TRANSACTION");
                    //musicQuery.clear();

            //}

            //musicDB.close();

}

