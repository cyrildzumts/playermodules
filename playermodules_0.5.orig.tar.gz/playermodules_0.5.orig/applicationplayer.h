#ifndef APPLICATIONPLAYER_H
#define APPLICATIONPLAYER_H

#include <QObject>
#include "utils.h"
#include "player.h"
#include "artistmodel.h"
#include "albummodel.h"
#include "genremodel.h"
#include "playlist.h"
#include "playlistmanager.h"
#include "playlistmodel.h"
#include "tracklistmodel.h"
#include "logger.h"

class ApplicationPlayer: public QObject
{
    Q_OBJECT
 //   Q_ENUMS(Utils::PlaybackMode)
//    Q_PROPERTY(TrackListModel albumContents READ albumContents WRITE setAlbumContents NOTIFY albumContentsChanged)
//    Q_PROPERTY(AlbumModel albumsModel READ albumsModel WRITE setAlbumsModel NOTIFY albumsModelChanged)
//    Q_PROPERTY(Playlist playlist READ playlist WRITE setPlaylist NOTIFY playlistChanged)
//    Q_PROPERTY(GenreModel genreModel READ genreModel WRITE setGenreModel NOTIFY genreModelChanged)
//    Q_PROPERTY(PlaylistModel playlistModel READ playlistModel WRITE setPlaylistModel NOTIFY playlistModelChanged)
//    Q_PROPERTY(TrackListModel allTrackModel READ allTrackModel WRITE setAllTrackModel NOTIFY allTrackModelChanged)
//    Q_PROPERTY(Utils::PlaybackMode playbackMode READ playbackMode WRITE setPlaybackMode NOTIFY playbackModeChanged)
//    Q_PROPERTY(int currentIndex READ currentIndex WRITE setCurrentIndex NOTIFY currentIndexChanged)
//    Q_PROPERTY(int mediaCount READ mediaCount)
//    Q_PROPERTY(QString  media READ media)
//    Q_PROPERTY(QString playingTitle READ playingTitle WRITE setPlayingTitle NOTIFY playingTitleChanged)
//    Q_PROPERTY(bool isEmpty READ isEmpty)
//    Q_PROPERTY(QString cover READ cover WRITE setCover NOTIFY coverChanged)
//    Q_PROPERTY(QMediaPlayer::State playerState READ playerState )

public:
    ApplicationPlayer(QObject *parent = 0);
    ~ApplicationPlayer();

    //
public Q_SLOTS:
    TrackListModel *albumContents();
    AlbumModel *albumsModel();
    Playlist *playlist();
    //GenreModel *genreModel();
    //PlaylistModel *playlistModel();
    TrackListModel *allTrackModel();
    int playbackMode();

    void goNext(QMediaPlayer::MediaStatus status);
    void setPlaybackMode(int mode);
    void setCurrentMedia(int index);
    void setCurrentMedia(QString url);
    void setAsPlaylist(int index = 0);

    // Player Interface
    QMediaPlayer::State playerState()const;
    void play();
    void next();
    void previous();
    void stop();
    void pause();
    void setMedia(QString &path);
    //void setCover(QString &path);

    // Playlist Interface
    void setCover(QString &path);
    QString cover()const;
    void setTracklist(std::vector<Utils::TrackTag> tracks);
    //std::vector<Utils::TrackTag> tracklist()const;

    int currentIndex()const;
    void setCurrentIndex(int index);

    void clearPlaylist();
    QString playingTitle()const;
    void setPlayingTitle(QString t);
    void addMedia(Utils::TrackTag track);
    void addMedia(std::vector<Utils::TrackTag> tracks);
    QString currentMedia()const;
    bool isEmpty()const;
    void insertMedia(int pos,Utils::TrackTag track);
    void insertMedia(int pos, std::vector<Utils::TrackTag> track);
    QString media(int index)const;
    QString media()const;
    int mediaCount()const;
    //int	nextIndex(int steps = 1) const;
    //int	previousIndex(int steps = 1) const;
    bool removeMedia(int pos);
    bool removeMedia(int start, int end);
    void save(const QUrl & location, const char * format = 0);
    void save(QIODevice * device, const char * format);
    std::vector<Utils::TrackTag> tracks()const;
    void shuffle();
    void repeat();


    // AlbumModel's Interface

    void albumModelrefresh();
    // QVariant data() ...
    //QVariant albumModelData(const QModelIndex &index, int role)const;
    // int albumModelRowCount(const QModelIndex &parent = QModelIndex())const;

    // TracklistModel's Interface
    void trackllistModelReset();
    void trackllistModelSetSourceID(int ID);
    int trackllistModelSourceID();
    std::vector<Utils::TrackTag> tracklistModelTracklist();

    // Database's Interface
    void scanSourceDirectory();
    void addToPlaylist(int trackID, int playlistID);
    void addToPlaylist(int trackID, QString playlist);
    int createPlaylist(QString &playlistName);
    void removePlaylist(int playlistID);
    void removePlaylist(QString& playlistName);
    void removeFromPlaylist(int trackID, int playlistID);
    void removeFromPlaylist(int trackID, QString playlist);
    void update();
    void playCountUp(int trackID);
    void addToFavorite(int trackID);
    int getLastAddedDate();
    int getLastModifiedDate();
    std::vector<QString> getTrackUrls();
    void setup();


Q_SIGNALS:
    void albumContentsChanged();
    void albumsModelChanged();
    void playlistChanged();
    void genreModelChanged();
    void playlistModelChanged();
    void allTrackModelChanged();

    // Playlist's Signals

    void coverChanged(QString coverPath);
    void nomedia();
    void tracklistChanged();
    void playingTitleChanged(QString newTitle);
    void playlistDataChanged();
    void currentMediaChanged(const Utils::TrackTag & content);
    void playbackModeChanged(int mode);
    void currentIndexChanged(int index);
    void playbackModeChanged();

private:
    Playlist::PlaybackMode _playbackMode;
    Player _player;
    Playlist *_playlist;
    TrackListModel *_albumContents;
    TrackListModel *_allTrackModel;
    //PlaylistModel *_playlistModel;
    //GenreModel *_genreModel;
    AlbumModel *_albumModel;
    Utils::Database _database;

};

#endif // APPLICATIONPLAYER_H
