#include "artistmodel.h"

ArtistModel::ArtistModel(QObject *parent) : QAbstractListModel(parent)
{

    configPath = QDir::homePath() + "/.Player/config";
    databaseName = configPath + "/player.db";
    connectionName  = "Logger";
    queryCmd = QString("SELECT * FROM Artist ORDER BY artistName  COLLATE NOCASE;");
    QLocale::setDefault(QLocale(QLocale::AnyLanguage));
}

ArtistModel::~ArtistModel()
{
    artistList.clear();
}

void ArtistModel::refresh()
{
    if(QFile::exists(databaseName))
    {
        QSqlDatabase db = QSqlDatabase::database(connectionName);
        Utils::Artist artist;
        artistList.clear();

        if(db.isOpen())
        {
            QSqlQuery artistQuery = QSqlQuery(db);
            artistQuery.exec(queryCmd);
            if(artistQuery.isActive())
            {

                while(artistQuery.next())
                {
                    artist.artistID = artistQuery.value("artistID").toInt();
                    artist.name = artistQuery.value("artistname").toString();
                    artist.description = artistQuery.value("description").toString();
                    beginInsertRows(QModelIndex(), rowCount(), rowCount());
                    artistList.push_back(artist);
                    endInsertRows();

                }
                //Q_EMIT dataChanged();

            }
            else
            {
                qDebug() << "debugQuery is not active";
            }
            artistQuery.finish();
        }
    }

    else
    {
        qDebug() << databaseName << " doesn't exists : ArtistModel::refresh()";
    }
}


QVariant ArtistModel::data(const QModelIndex &index, int role) const
{

    // Version 3.

    if (index.row() < 0 || index.row() >= rowCount()  )
            return QVariant();

     else
    {
        Utils::Artist artist = artistList.at(index.row());
        switch (role)
        {
            case ArtistNameRole:
                return artist.name;

            case ArtistIDRole:
                return artist.artistID;

            case DescriptionRole:
                return artist.description;

            default:
                return QVariant();
        }
    }

}

QHash<int,QByteArray> ArtistModel::roleNames() const
{
      QHash<int, QByteArray> roles;
      roles[ArtistIDRole] = "artistID";
      roles[ArtistNameRole] = "artist";
      roles[DescriptionRole] = "description";
      return roles;
}

int ArtistModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);

    return artistList.size();
}


void ArtistModel::resetInternalData()
{
    beginResetModel();
    artistList.clear();
    endResetModel();
    Q_EMIT dataChanged();
}

