#ifndef UPDATEDB_H
#define UPDATEDB_H

#include <QObject>
#include <QtSql>

class UpdateDB : public QObject
{
    Q_OBJECT
public:
    explicit UpdateDB(QObject *parent = 0);
     ~UpdateDB();

Q_SIGNALS:
    void finished();
    void error(QString err);


public Q_SLOTS:
    void updateDatabase();

private:
    void fillDATABASE(const QString &dirPath, QSqlQuery *musicQuery);

};

#endif // UPDATEDB_H
