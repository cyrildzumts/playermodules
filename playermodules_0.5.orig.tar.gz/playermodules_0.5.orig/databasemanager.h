#ifndef DATABASEMANAGER_H
#define DATABASEMANAGER_H

#include <QObject>
#include <QThread>
#include <QFileSystemWatcher>
#include "logger.h"


class DatabaseManager : public QObject
{
    Q_OBJECT
public:
    explicit DatabaseManager(QObject *parent = 0);
    ~DatabaseManager();

Q_SIGNALS:
 void fullScanClicked();
 void databaseChanged();
 void updateClicked();
 void playlistsModelChanged();


public Q_SLOTS:
void update();
void fullScan();
void setup();
int createPlaylist(QString name); //  return the playlistID
void removePlaylist(int playlistID);
void addToPlaylist(int playlistID, int trackID); // Return the trackID in this playlist
void removeFromPlaylist(int playlistID, int trackID);

private:
    bool sourceHasChanged;
    QString watchedDir;
    Utils::Database *database;
    QThread *updateJob;
    QFileSystemWatcher *musicWatcher;

};

#endif // DATABASEMANAGER_H
