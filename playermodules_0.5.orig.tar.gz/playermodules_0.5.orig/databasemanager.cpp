#include "databasemanager.h"

DatabaseManager::DatabaseManager(QObject *parent) :
    QObject(parent)
{
    watchedDir = QStandardPaths::locate(QStandardPaths::MusicLocation,"",QStandardPaths::LocateDirectory);
    database = new Utils::Database;
    //updateJob = new QThread;
    musicWatcher = new QFileSystemWatcher;

    //database->moveToThread(updateJob);
    musicWatcher->addPath(watchedDir);

    qDebug()<< "DatabaseManager's Constructor : Music dirpath is : " << watchedDir ;

    //connect(musicWatcher,SIGNAL(directoryChanged(QString)),updateJob,SLOT(start()));
    //connect(updateJob,SIGNAL(started()),database,SLOT(update()));
    //connect(database,SIGNAL(updateJobFinished()),updateJob,SLOT(quit()));
    connect(database,SIGNAL(updateJobFinished()),this,SIGNAL(databaseChanged()));
    connect(database,SIGNAL(scanSourceDirectoryFinished()),this,SIGNAL(databaseChanged()));
    connect(database,SIGNAL(scanSourceDirectoryFinished()),database,SLOT(setup()));
    //connect(database,SIGNAL(playlistsModelChanged()), this, SIGNAL(playlistsModelChanged()));

    //connect(updateJob, SIGNAL(finished()),updateJob, SLOT(deleteLater()));


}

DatabaseManager::~DatabaseManager()
{
    delete musicWatcher;
    updateJob->quit();
    updateJob->deleteLater();
    delete database;
    delete updateJob;
}

int DatabaseManager::createPlaylist(QString name)
{
    Q_EMIT playlistsModelChanged();
    return database->createPlaylist(name);

}

void DatabaseManager::removeFromPlaylist(int playlistID, int trackID)
{
    database->removeFromPlaylist(trackID,playlistID);
    Q_EMIT playlistsModelChanged();
}

void DatabaseManager::removePlaylist(int playlistID)
{
    database->removePlaylist(playlistID);
    Q_EMIT playlistsModelChanged();
}

void DatabaseManager::addToPlaylist(int playlistID, int trackID)
{
    database->addToPlaylist(trackID, playlistID);
    Q_EMIT playlistsModelChanged();
}

void DatabaseManager::fullScan()
{
    database->scanSourceDirectory();
    //updateJob->start();
}

void DatabaseManager::update()
{
    database->update();
    //updateJob->start();
    Q_EMIT databaseChanged();
}

void DatabaseManager::setup()
{
    database->setup();
    //updateJob->start();
}
